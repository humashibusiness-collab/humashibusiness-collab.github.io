Star Crucible / 星のるつぼ - press kit
Free to use for coverage, videos and streams.
Trailer: https://humashibusiness-collab.github.io/assets/star-crucible/trailer_en.mp4
Demo: https://humashi.itch.io/star-crucible
Contact: humashilabs@gmail.com
